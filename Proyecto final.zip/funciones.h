// --- Includes de librerías estándar ---
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// --- Definiciones de Estructuras ---
struct Clima {
    float temp; 
    float viento; 
    float hum;  
};

struct DatosDia {
    float pm25;
    float pm10;
    float co;
    float no2;
    float o3;
    struct Clima cli; 
    char fecha[20]; 
};

struct Zona {
    char nom[50]; 
    int id;
    struct DatosDia act; 
    struct DatosDia hist[30]; 
    int num_reg; 
    float pred;
    int alerta;
};

struct Sistema {
    struct Zona *zonas; 
    int num_zonas; 
    int cap_zonas; 
};

// --- Declaraciones de Funciones ---
float calc_ind(struct DatosDia *datos);
void calc_pred(struct Zona *zona);
void cargar(struct Sistema *sis);
void guardar(struct Sistema *sis);
void ing_dat_man(struct Sistema *sis);
void ver_alertas(struct Sistema *sis);
void exp_rep(struct Sistema *sis);
float prom_hist(struct Zona *zona);
void add_zona(struct Sistema *sis);
int buscar_zona_idx(struct Sistema *sis, char *nombre_zona);
void init_sis(struct Sistema *sis);
void liberar_sis(struct Sistema *sis);

void mostrar_menu_principal();
void mostrar_menu_sin_zonas();
void limpiar_buffer();

// Funciones para mostrar información específica
void ver_estado(struct Sistema *sis);
void ver_pred(struct Sistema *sis);
void ver_det_alertas(struct Sistema *sis); 
void ver_proms(struct Sistema *sis);
void ver_recos(struct Sistema *sis); 


// --- Implementaciones de Funciones ---

// Funciones de monitoreo y gestión
float calc_ind(struct DatosDia *datos) {
    float i25 = ((*datos).pm25 / 25.0) * 50.0;
    float i10 = ((*datos).pm10 / 50.0) * 50.0;
    float imax = (i25 > i10) ? i25 : i10;
    imax += ((*datos).co / 10.0) * 5.0;
    imax += ((*datos).no2 / 40.0) * 10.0;
    return imax;
}

void calc_pred(struct Zona *zona) {
    if((*zona).num_reg < 3) {
        (*zona).pred = calc_ind(&(*zona).act);
        return;
    }
    float sum = 0.0;
    float peso_total = 0.0;
    int dias = ((*zona).num_reg < 7) ? (*zona).num_reg : 7;
    for(int i = 0; i < dias; i++) {
        int idx = (*zona).num_reg - 1 - i;
        float peso = (float)(dias - i) / dias;
        float ind = calc_ind(&(*zona).hist[idx]);
        sum += ind * peso;
        peso_total += peso;
    }
    float pred_base = sum / peso_total;
    float f_viento = 1.0;
    if((*zona).act.cli.viento > 10.0) f_viento = 0.8;
    else if((*zona).act.cli.viento < 5.0) f_viento = 1.2;
    float f_humedad = 1.0;
    if((*zona).act.cli.hum > 70.0) f_humedad = 1.1;
    (*zona).pred = pred_base * f_viento * f_humedad;
}

void cargar(struct Sistema *sis) {
    FILE *f = fopen("datos.txt", "r");
    if(f == NULL) {
        printf("Sin datos previos. Iniciando con sistema vacio.\n");
        (*sis).num_zonas = 0;
        (*sis).cap_zonas = 0;
        (*sis).zonas = NULL;
        return;
    }

    fscanf(f, "%d", &(*sis).num_zonas);
    (*sis).cap_zonas = (*sis).num_zonas;

    if ((*sis).num_zonas > 0) {
        (*sis).zonas = (struct Zona *)malloc((*sis).num_zonas * sizeof(struct Zona));
        if ((*sis).zonas == NULL) {
            printf("Error: No se pudo asignar memoria para las zonas al cargar.\n");
            (*sis).num_zonas = 0;
            (*sis).cap_zonas = 0;
            fclose(f);
            return;
        }
    } else {
        (*sis).zonas = NULL;
    }

    for(int i = 0; i < (*sis).num_zonas; i++) {
        fscanf(f, "%49s %d %d", (*sis).zonas[i].nom, &(*sis).zonas[i].id, &(*sis).zonas[i].num_reg);
        for(int j = 0; j < (*sis).zonas[i].num_reg && j < 30; j++) {
            fscanf(f, "%f %f %f %f %f %f %f %f %s",
                   &(*sis).zonas[i].hist[j].pm25,
                   &(*sis).zonas[i].hist[j].pm10,
                   &(*sis).zonas[i].hist[j].co,
                   &(*sis).zonas[i].hist[j].no2,
                   &(*sis).zonas[i].hist[j].o3,
                   &(*sis).zonas[i].hist[j].cli.temp,
                   &(*sis).zonas[i].hist[j].cli.viento,
                   &(*sis).zonas[i].hist[j].cli.hum,
                   (*sis).zonas[i].hist[j].fecha);
        }
        if ((*sis).zonas[i].num_reg > 0) {
            (*sis).zonas[i].act = (*sis).zonas[i].hist[(*sis).zonas[i].num_reg - 1];
        } else {
            (*sis).zonas[i].alerta = 0;
            (*sis).zonas[i].pred = 0.0;
            strcpy((*sis).zonas[i].act.fecha, "N/A");
        }
    }
    fclose(f);
    printf("Datos cargados.\n");
}

void guardar(struct Sistema *sis) {
    FILE *f = fopen("datos.txt", "w");
    if(f == NULL) {
        printf("Error guardando datos.\n");
        return;
    }
    fprintf(f, "%d\n", (*sis).num_zonas);
    for(int i = 0; i < (*sis).num_zonas; i++) {
        fprintf(f, "%s %d %d\n", (*sis).zonas[i].nom, (*sis).zonas[i].id, (*sis).zonas[i].num_reg);
        for(int j = 0; j < (*sis).zonas[i].num_reg; j++) {
            fprintf(f, "%.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f %s\n",
                    (*sis).zonas[i].hist[j].pm25,
                    (*sis).zonas[i].hist[j].pm10,
                    (*sis).zonas[i].hist[j].co,
                    (*sis).zonas[i].hist[j].no2,
                    (*sis).zonas[i].hist[j].o3,
                    (*sis).zonas[i].hist[j].cli.temp,
                    (*sis).zonas[i].hist[j].cli.viento,
                    (*sis).zonas[i].hist[j].cli.hum,
                    (*sis).zonas[i].hist[j].fecha);
        }
    }
    fclose(f);
}

void ing_dat_man(struct Sistema *sis) {
    if ((*sis).num_zonas == 0) {
        printf("No hay zonas registradas. Por favor, añada una zona primero.\n");
        return;
    }

    char fecha_str[20];
    printf("\n=== INGRESO DE NUEVOS DATOS ===\n");
    printf("Ingrese fecha y hora (AAAA-MM-DD_HH:MM): ");
    scanf("%19s", fecha_str);
    limpiar_buffer();

    printf("Fecha para los registros: %s\n", fecha_str);

    char nombre_zona[50];
    printf("Ingrese el nombre de la zona para registrar datos (o 'todas' para todas las zonas): ");
    scanf("%49s", nombre_zona);
    limpiar_buffer();

    int idx_zona = -1;
    int procesar_todas = 0;

    if (strcmp(nombre_zona, "todas") == 0 || strcmp(nombre_zona, "Todas") == 0) {
        procesar_todas = 1;
    } else {
        idx_zona = buscar_zona_idx(sis, nombre_zona);
        if (idx_zona == -1) {
            printf("Zona '%s' no encontrada. No se registrarán datos para esta zona.\n", nombre_zona);
            return;
        }
    }

    for(int i = 0; i < (*sis).num_zonas; i++) {
        if (!procesar_todas && i != idx_zona) {
            continue;
        }

        struct Zona *zona = &(*sis).zonas[i];
        printf("\n--- %s ---\n", (*zona).nom);
        printf("PM2.5 (ug/m3): ");
        scanf("%f", &(*zona).act.pm25);
        limpiar_buffer();
        printf("PM10 (ug/m3): ");
        scanf("%f", &(*zona).act.pm10);
        limpiar_buffer();
        printf("CO (ppm): ");
        scanf("%f", &(*zona).act.co);
        limpiar_buffer();
        printf("NO2 (ppb): ");
        scanf("%f", &(*zona).act.no2);
        limpiar_buffer();
        printf("O3 (ppb): ");
        scanf("%f", &(*zona).act.o3);
        limpiar_buffer();
        printf("Temperatura (C): ");
        scanf("%f", &(*zona).act.cli.temp);
        limpiar_buffer();
        printf("Velocidad del viento (km/h): ");
        scanf("%f", &(*zona).act.cli.viento);
        limpiar_buffer();
        printf("Humedad (%%): ");
        scanf("%f", &(*zona).act.cli.hum);
        limpiar_buffer();
        strcpy((*zona).act.fecha, fecha_str);
        if((*zona).num_reg < 30) {
            (*zona).hist[(*zona).num_reg] = (*zona).act;
            (*zona).num_reg++;
        } else {
            for(int j = 0; j < 29; j++) {
                (*zona).hist[j] = (*zona).hist[j + 1];
            }
            (*zona).hist[29] = (*zona).act;
        }
        calc_pred(zona);
        if (!procesar_todas) {
            break;
        }
    }
    ver_alertas(sis);
}

void ver_alertas(struct Sistema *sis) {
    for(int i = 0; i < (*sis).num_zonas; i++) {
        struct Zona *zona = &(*sis).zonas[i];
        float ind = calc_ind(&(*zona).act);
        if(ind > 100.0 || (*zona).pred > 100.0 || (*zona).act.pm25 > 50.0 || (*zona).act.pm10 > 100.0) {
            (*zona).alerta = 1;
        } else {
            (*zona).alerta = 0;
        }
    }
}

void exp_rep(struct Sistema *sis) {
    FILE *f = fopen("reporte.txt", "w");
    if(f == NULL) {
        printf("Error creando reporte.\n");
        return;
    }
    char fecha_rep[20];
    if ((*sis).num_zonas > 0 && (*sis).zonas[0].num_reg > 0) {
        strcpy(fecha_rep, (*sis).zonas[0].act.fecha);
    } else {
        strcpy(fecha_rep, "N/A");
    }
    fprintf(f, "REPORTE CONTAMINACION\n");
    fprintf(f, "=====================\n");
    fprintf(f, "Fecha del Reporte: %s\n\n", fecha_rep);
    fprintf(f, "ESTADO ACTUAL:\n");
    fprintf(f, "--------------\n");
    for(int i = 0; i < (*sis).num_zonas; i++) {
        struct Zona *zona = &(*sis).zonas[i];
        fprintf(f, "\n%s:\n", (*zona).nom);
        fprintf(f, "  PM2.5: %.2f\n", (*zona).act.pm25);
        fprintf(f, "  PM10: %.2f\n", (*zona).act.pm10);
        fprintf(f, "  Indice: %.2f\n", calc_ind(&(*zona).act));
        fprintf(f, "  Prediccion: %.2f\n", (*zona).pred);
        fprintf(f, "  Estado: %s\n", (*zona).alerta ? "ALERTA" : "NORMAL");
        fprintf(f, "  Temp: %.1f, Viento: %.1f, Hum: %.1f\n",
                (*zona).act.cli.temp, (*zona).act.cli.viento, (*zona).act.cli.hum);
    }
    fprintf(f, "\nALERTAS:\n");
    fprintf(f, "--------\n");
    int num_alertas = 0;
    for(int i = 0; i < (*sis).num_zonas; i++) {
        if((*sis).zonas[i].alerta) {
            fprintf(f, "ALERTA: %s\n", (*sis).zonas[i].nom);
            num_alertas++;
        }
    }
    if(num_alertas == 0) {
        fprintf(f, "Sin alertas activas\n");
    }
    fclose(f);
    printf("Reporte exportado a 'reporte.txt'\n");
}

float prom_hist(struct Zona *zona) {
    if((*zona).num_reg == 0) return 0.0;
    float sum = 0.0;
    for(int i = 0; i < (*zona).num_reg; i++) {
        sum += calc_ind(&(*zona).hist[i]);
    }
    return sum / (*zona).num_reg;
}

void add_zona(struct Sistema *sis) {
    char nuevo_nom[50];
    printf("\nIngrese el nombre de la nueva zona: ");
    scanf("%49s", nuevo_nom);
    limpiar_buffer();

    if (buscar_zona_idx(sis, nuevo_nom) != -1) {
        printf("Error: La zona '%s' ya existe.\n", nuevo_nom);
        return;
    }

    if ((*sis).num_zonas >= (*sis).cap_zonas) {
        int nueva_cap = ((*sis).cap_zonas == 0) ? 2 : (*sis).cap_zonas * 2;
        struct Zona *temp = (struct Zona *)realloc((*sis).zonas, nueva_cap * sizeof(struct Zona));
        if (temp == NULL) {
            printf("Error: No se pudo reasignar memoria para nuevas zonas.\n");
            return;
        }
        (*sis).zonas = temp;
        (*sis).cap_zonas = nueva_cap;
        printf("Capacidad de zonas aumentada a %d.\n", (*sis).cap_zonas);
    }

    struct Zona *nueva_zona = &(*sis).zonas[(*sis).num_zonas];
    strcpy((*nueva_zona).nom, nuevo_nom);
    (*nueva_zona).id = (*sis).num_zonas + 1;
    (*nueva_zona).num_reg = 0;
    (*nueva_zona).alerta = 0;
    (*nueva_zona).pred = 0.0;
    strcpy((*nueva_zona).act.fecha, "N/A");

    (*sis).num_zonas++;
    printf("Zona '%s' añadida con éxito. ID: %d\n", nuevo_nom, (*nueva_zona).id);
}

int buscar_zona_idx(struct Sistema *sis, char *nombre_zona) {
    for (int i = 0; i < (*sis).num_zonas; i++) {
        if (strcmp((*sis).zonas[i].nom, nombre_zona) == 0) {
            return i;
        }
    }
    return -1;
}

void init_sis(struct Sistema *sis) {
    (*sis).zonas = NULL;
    (*sis).num_zonas = 0;
    (*sis).cap_zonas = 0;
}

void liberar_sis(struct Sistema *sis) {
    if ((*sis).zonas != NULL) {
        free((*sis).zonas);
        (*sis).zonas = NULL;
    }
    (*sis).num_zonas = 0;
    (*sis).cap_zonas = 0;
}

// Funciones para mostrar información específica
void ver_estado(struct Sistema *sis) {
    if ((*sis).num_zonas == 0) {
        printf("No hay zonas registradas en el sistema.\n");
        return;
    }
    printf("\n=== ESTADO ACTUAL DEL SISTEMA ===\n");
    for(int i = 0; i < (*sis).num_zonas; i++) {
        struct Zona *zona = &(*sis).zonas[i];
        printf("\n%s (ID: %d):\n", (*zona).nom, (*zona).id);
        printf("  Fecha ultimo registro: %s\n", (*zona).act.fecha);
        printf("  PM2.5: %.2f %s\n", (*zona).act.pm25,
               ((*zona).act.pm25 > 25.0) ? "ALTO" : "OK");
        printf("  PM10: %.2f %s\n", (*zona).act.pm10,
               ((*zona).act.pm10 > 50.0) ? "ALTO" : "OK");
        printf("  Indice de Calidad del Aire: %.2f\n", calc_ind(&(*zona).act));
        printf("  Clima: Temp: %.1fC, Viento: %.1fkm/h, Humedad: %.1f%%\n",
               (*zona).act.cli.temp, (*zona).act.cli.viento, (*zona).act.cli.hum);
        printf("  Registros historicos: %d\n", (*zona).num_reg);
    }
}

void ver_pred(struct Sistema *sis) {
    if ((*sis).num_zonas == 0) {
        printf("No hay zonas registradas en el sistema.\n");
        return;
    }
    printf("\n=== PREDICCIONES DE CONTAMINACION (24H) ===\n");
    for(int i = 0; i < (*sis).num_zonas; i++) {
        struct Zona *zona = &(*sis).zonas[i];
        if ((*zona).num_reg == 0) {
            printf("\n%s: Sin datos para prediccion.\n", (*zona).nom);
            continue;
        }
        calc_pred(zona);
        printf("\n%s:\n", (*zona).nom);
        printf("  Indice Actual: %.2f\n", calc_ind(&(*zona).act));
        printf("  Prediccion Indice: %.2f - Estado: %s\n", (*zona).pred,
               ((*zona).pred > 100.0) ? "CRITICO (¡Alerta!)" :
               ((*zona).pred > 50.0) ? "CUIDADO (Aire Moderado)" : "BUENO (Aire Saludable)");
    }
}

void ver_det_alertas(struct Sistema *sis) {
    if ((*sis).num_zonas == 0) {
        printf("No hay zonas registradas en el sistema.\n");
        return;
    }
    printf("\n=== VERIFICAR ALERTAS ACTIVAS ===\n");
    int hay_alertas = 0;
    for(int i = 0; i < (*sis).num_zonas; i++) {
        if((*sis).zonas[i].alerta) {
            printf("--- ALERTA ACTIVA: %s ---\n", (*sis).zonas[i].nom);
            printf("    Indice Actual: %.2f\n", calc_ind(&(*sis).zonas[i].act));
            printf("    Prediccion: %.2f\n", (*sis).zonas[i].pred);
            hay_alertas = 1;
        }
    }
    if(!hay_alertas) {
        printf("Actualmente no hay alertas activas en ninguna zona.\n");
    }
}

void ver_proms(struct Sistema *sis) {
    if ((*sis).num_zonas == 0) {
        printf("No hay zonas registradas en el sistema.\n");
        return;
    }
    printf("\n=== PROMEDIOS HISTORICOS POR ZONA ===\n");
    for(int i = 0; i < (*sis).num_zonas; i++) {
        struct Zona *zona = &(*sis).zonas[i];
        if((*zona).num_reg == 0) {
            printf("\n%s: Sin datos historicos para promedios.\n", (*zona).nom);
            continue;
        }
        float s25 = 0.0, s10 = 0.0;
        for(int j = 0; j < (*zona).num_reg; j++) {
            s25 += (*zona).hist[j].pm25;
            s10 += (*zona).hist[j].pm10;
        }
        float p25 = s25 / (*zona).num_reg;
        float p10 = s10 / (*zona).num_reg;
        printf("\n%s:\n", (*zona).nom);
        printf("  PM2.5 promedio historico: %.2f ug/m3 (Ref: 25.0) - Estado: %s\n",
               p25, (p25 > 25.0) ? "POR ENCIMA" : "NORMAL");
        printf("  PM10 promedio historico: %.2f ug/m3 (Ref: 50.0) - Estado: %s\n",
               p10, (p10 > 50.0) ? "POR ENCIMA" : "NORMAL");
    }
}

void ver_recos(struct Sistema *sis) {
    if ((*sis).num_zonas == 0) {
        printf("No hay zonas registradas para recomendaciones.\n");
        return;
    }
    printf("\n=== RECOMENDACIONES DE ACCION ===\n");
    int hay_riesgo = 0;
    for(int i = 0; i < (*sis).num_zonas; i++) {
        struct Zona *zona = &(*sis).zonas[i];
        if((*zona).alerta || (*zona).act.pm25 > 25.0 || (*zona).act.pm10 > 50.0 || calc_ind(&(*zona).act) > 50.0) {
            hay_riesgo = 1;
            printf("\n--- RECOMENDACIONES PARA: %s ---\n", (*zona).nom);
            if(strstr((*zona).nom, "Industrial") != NULL || strstr((*zona).nom, "industria") != NULL) {
                printf("  - Restriccion de actividades industriales.\n");
                printf("  - Evaluar sistemas de filtrado de emisiones.\n");
            }
            if(strstr((*zona).nom, "Avenida") != NULL || strstr((*zona).nom, "Transito") != NULL || strstr((*zona).nom, "Centro") != NULL) {
                printf("  - Aplicar restricciones vehiculares (pico y placa extendido).\n");
                printf("  - Fomentar transporte publico y alternativo.\n");
            }
            printf("  - **Recomendaciones Generales para Poblacion:**\n");
            printf("    - Evite actividades fisicas intensas al aire libre.\n");
            printf("    - Use mascarillas (FFP2/N95) si debe salir.\n");
            printf("    - Mantenga puertas y ventanas cerradas.\n");
            if((*zona).act.cli.viento < 5.0 && ((*zona).alerta || calc_ind(&(*zona).act) > 70.0)) {
                printf("    - **Nota:** Vientos debiles limitan dispersion. Medidas mas estrictas.\n");
            }
            if((*zona).act.cli.hum > 70.0 && ((*zona).alerta || calc_ind(&(*zona).act) > 70.0)) {
                printf("    - **Nota:** Alta humedad puede agravar. Preste atencion especial.\n");
            }
        }
    }
    if(!hay_riesgo) {
        printf("Condiciones del aire aceptables. No se requieren medidas de emergencia.\n");
        printf("\nRecomendaciones para mantener buena calidad del aire:\n");
        printf("  - Promover transporte sostenible.\n");
        printf("  - Aumentar areas verdes.\n");
        printf("  - Impulsar energias limpias.\n");
        printf("  - Mantenimiento preventivo de vehiculos e industrias.\n");
    }
}

// Funciones para MOSTRAR los menús (solo imprimen el texto)
void mostrar_menu_principal() {
    printf("\n--- GESTION DE MONITOREO AMBIENTAL ---\n");
    printf("======================================\n");
    printf("1. Ver Estado Actual\n");
    printf("2. Ver Predicciones\n");
    printf("3. Ver Promedios Historicos\n");
    printf("4. Ver Alertas Activas\n");
    printf("5. Ver Recomendaciones\n");
    printf("6. Ingresar Datos\n");
    printf("7. Anadir Zona\n");
    printf("8. Exportar Reporte\n");
    printf("9. Guardar Cambios\n");
    printf("0. Salir\n");
    printf("======================================\n");
    printf("Seleccione una opcion: ");
}

void mostrar_menu_sin_zonas() {
    printf("\n--- SISTEMA SIN ZONAS REGISTRADAS ---\n");
    printf("======================================\n");
    printf("1. Anadir Nueva Zona\n");
    printf("2. Cargar Datos\n");
    printf("0. Salir\n");
    printf("======================================\n");
    printf("Seleccione una opcion: ");
}

// Función auxiliar para limpiar el buffer de entrada
void limpiar_buffer() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}