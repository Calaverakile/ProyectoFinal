#include "funciones.h"

int main() {
    struct Sistema sist; 
    int opcion; 

    printf("=== BIENVENIDO AL SISTEMA DE MONITOREO DE CONTAMINACION ===\n");
    printf("Cargando datos iniciales...\n");

    init_sis(&sist); 
    cargar(&sist); 

    do {
        // Lógica principal del menú
        if (sist.num_zonas == 0) { 
            mostrar_menu_sin_zonas();
            scanf("%d", &opcion);
            limpiar_buffer();

            switch(opcion) {
                case 1:
                    add_zona(&sist);
                    break;
                case 2:
                    cargar(&sist); // Re-intentar cargar datos
                    if (sist.num_zonas > 0) {
                        printf("\nDatos cargados con exito. Accediendo al menu principal.\n");
                    } else {
                        printf("\nNo se encontraron datos validos para cargar.\n");
                    }
                    break;
                case 0:
                    printf("\nSaliendo del programa. ¡Hasta pronto!\n");
                    break;
                default:
                    printf("\nOpcion no valida. Por favor, intente de nuevo.\n");
                    break;
            }
        } else { // Si hay zonas registradas, mostrar el menú principal completo
            mostrar_menu_principal();
            scanf("%d", &opcion);
            limpiar_buffer();

            switch(opcion) {
                case 1: ver_estado(&sist); break;
                case 2: ver_pred(&sist); break;
                case 3: ver_proms(&sist); break;
                case 4: ver_alertas(&sist); ver_det_alertas(&sist); break;
                case 5: ver_recos(&sist); break;
                case 6: ing_dat_man(&sist); printf("\nDatos ingresados y actualizados con exito.\n"); break;
                case 7: add_zona(&sist); break;
                case 8: exp_rep(&sist); break;
                case 9: guardar(&sist); printf("\nDatos guardados correctamente.\n"); break;
                case 0:
                    guardar(&sist); // Guardar antes de salir
                    printf("\nSaliendo del programa. ¡Hasta pronto!\n");
                    break;
                default:
                    printf("\nOpcion no valida. Por favor, ingrese un numero valido.\n");
                    break;
            }
        }

        // Pausa para que el usuario pueda leer la salida, excepto al salir
        if (opcion != 0) {
            printf("\nPresione ENTER para continuar...");
            getchar(); // Espera ENTER
        }

    } while(opcion != 0);

    liberar_sis(&sist); // Liberar la memoria al finalizar el programa
    return 0;
}